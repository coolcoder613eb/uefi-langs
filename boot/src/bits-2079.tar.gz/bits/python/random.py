# Stub module to support modules that import random but don't always call it
